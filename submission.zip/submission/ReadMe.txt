To compile enter:
make

to run enter:
./main

Note: the file Read.txt contains input data and should be in the same folder with this name